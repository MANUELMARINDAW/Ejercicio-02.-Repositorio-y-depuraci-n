package ejercicio2;

public class Card {

	// DECLARACION DE VARIABLES 
	
	//suit tipo string
	public String suit;
	//value tipo string
	public String value;
	
	//Declaramos que una card consiste de dos strings siendo suit y value
	public Card (String suit, String value) {
		this.suit = suit;
		this.value = value;
	}
	//Este metodo devuelve simplemente el suit y el value separado de un -
	//Para cuando imprimamos una carta mostrar con el formato dado
	public String toString () {
		return (this.suit+"-"+this.value);
	}
}
