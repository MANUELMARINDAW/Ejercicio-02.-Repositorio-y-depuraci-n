package ejercicio2;

import java.util.ArrayList;

public class DeckCards {

	public static void main(String[] args) {
		
		// DECLARACION DE LISTAS 
		
		//Declaramos que puede ser un suit y lo guardamos en una lista:
		String[] suits = { "Spades", "Diamonds", "Club", "Heart" };
		//Declaramos que valores puede tener una carta y lo guardamos en una lista
		String[] values = { "Ace", "2", "3", "4", "5", "6", "7", "8", "9", "10", "Jack", "Queen", "King" };

		/* Usamos la funcion Arraylist para declara que la variable deck consiste de lo que es una Card es  
		 * decir dos strings siendo el suit y el value/*
		 */
		ArrayList<Card> deck = new ArrayList<Card>();

		//GUARDAR LAS CARTAS EN EL MAZO
		// El primer bucle que toma la longitud de suits 
		for (int i = 0; i < suits.length; i++) { 
			//Dentro de este bucle por cada suit le asignaremos los valores de la carta
			for (int j = 0; j < values.length; j++) { // Para ello lo haremos hasta la longitud de values 
				Card card = new Card(suits[i], values[j]); // Declara una nueva carta que tendra el tipo y el valor actual
				deck.add(card); // Lo añade al mazo es decir ejemplo añade SPADES ACE
			}
		}

		//BARAJAR MAZO
		for (int i = 0; i < deck.size(); i++) { // Por la cantidad de cartas del mazo barajeara todas las cartas
			
			// Declaramos j que sera un numero aleatorio 
			int j = (int) Math.floor(Math.random() * i);
			// Declaramos una variable temporal de tipo card que sera la carta actual del mazo 
			Card tmp = deck.get(i); 
			// Declaramos que la carta actual se cambiara con la posicion de J que es un numero aleaotrio
			deck.set(i, deck.get(j)); 
			// Declaramos que la carta de la posicion J es igual a temp que era la carta original en la posicion que estabamos viendo
			deck.set(j, tmp); 
			/* Es decir lo que hemos hecho es cambiar posiciones en el mazo simplemente barajar
			 * se necesita un variable temporal para almacenar la carta si no se pierde */
		}

		// Ahora imprimiremos las primeros 5 cartas del mazo barajado
		for (int i = 0; i < 5; i++) { 
			System.out.println(deck.get(i));
		}

	}

}
